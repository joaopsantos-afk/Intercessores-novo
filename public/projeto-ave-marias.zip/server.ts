import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import webpush from 'web-push';
import QRCode from 'qrcode';
import { AppState, Intercessor, Week, PrayerRecord, NotificationLog, WebhookStatus } from './src/types';
import { getInitialAppState } from './src/initialData';
import { getBrasiliaNow, getWeekBoundsForDate, formatWeekPeriod } from './src/utils/date';

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

app.use(express.json());

// VAPID keys for Web Push Notifications (works even with browser/site closed)
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || 'BEYSGRtjXgKjTPfzevFgK1t0qSnFHsk43B_pkw1L16nl_mYZ94_LopIOdiDTWzUMs9nu1vyUnMaEGjluZqkLt8o';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || 'BjH1_L7DLugBjnQsELOUCU72nBAd29o427Bd41XCBao';
const VAPID_SUBJECT = 'mailto:contato@intercessao.org';

webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

// Persistent local database path
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'db.json');
const SUBSCRIPTIONS_FILE = path.resolve(DATA_DIR, 'push_subscriptions.json');

// Store push subscriptions
let pushSubscriptions: any[] = [];
try {
  if (fs.existsSync(SUBSCRIPTIONS_FILE)) {
    pushSubscriptions = JSON.parse(fs.readFileSync(SUBSCRIPTIONS_FILE, 'utf-8'));
  }
} catch (e) {
  console.error('Error loading push subscriptions:', e);
}

function saveSubscriptions() {
  try {
    fs.writeFileSync(SUBSCRIPTIONS_FILE, JSON.stringify(pushSubscriptions, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error saving push subscriptions:', e);
  }
}

async function sendPushToAll(title: string, body: string, url: string = '/') {
  const payload = JSON.stringify({ title, body, url });
  const activeSubs = [...pushSubscriptions];
  const invalidEndpoints: string[] = [];

  for (const sub of activeSubs) {
    try {
      await webpush.sendNotification(sub, payload);
    } catch (err: any) {
      if (err.statusCode === 404 || err.statusCode === 410) {
        invalidEndpoints.push(sub.endpoint);
      } else {
        console.error('Push notification delivery error:', err.message);
      }
    }
  }

  if (invalidEndpoints.length > 0) {
    pushSubscriptions = pushSubscriptions.filter(s => !invalidEndpoints.includes(s.endpoint));
    saveSubscriptions();
  }
}

// Ensure local data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// In-memory state with 100% local file persistence
let state: AppState = getInitialAppState();

function loadStateFromLocalFile() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.intercessors) && Array.isArray(parsed.weeks)) {
        state = parsed;
        console.log('⚡ Banco de dados local carregado com sucesso de data/db.json!');
        return;
      }
    }
  } catch (e) {
    console.error('Erro ao ler data/db.json local:', e);
  }

  state = getInitialAppState();
  saveStateToFile(state);
}

function saveStateToFile(newState: AppState) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(newState, null, 2), 'utf-8');
  } catch (err) {
    console.error('Erro ao salvar em data/db.json:', err);
  }
}

// Initialize local database
loadStateFromLocalFile();

// Ensure current week is initialized according to current Brasília time
// Defaults to Week 17 ('2026-09-28') as specified in Section 39
function ensureCurrentWeek(): Week {
  const brtNow = getBrasiliaNow();
  const bounds = getWeekBoundsForDate(brtNow);

  // If current calendar date is on or after 2026-09-28, use actual week; otherwise stay on Week 17
  const isPastWeek17 = bounds.startDate >= '2026-09-28';
  const targetWeekId = isPastWeek17 ? bounds.weekId : '2026-09-28';

  let currentWeek = state.weeks.find(w => w.id === targetWeekId);
  const activeMembers = state.intercessors.filter(i => i.active);

  if (!currentWeek) {
    // Determine week number relative to Week 17
    const lastWeek = [...state.weeks].sort((a, b) => b.weekNumber - a.weekNumber)[0];
    const nextWeekNumber = (lastWeek?.weekNumber || 16) + 1;

    currentWeek = {
      id: bounds.weekId,
      weekNumber: nextWeekNumber,
      startDate: bounds.startDate,
      endDate: bounds.endDate,
      targetPerMember: 140,
      memberCountAtWeek: activeMembers.length,
      totalTarget: activeMembers.length * 140,
      hasIndividualData: true,
      whatsappSent: false,
      whatsappSentAt: null,
      lastWebhookStatus: null,
    };
    state.weeks.push(currentWeek);
    state.currentWeekId = currentWeek.id;
    saveStateToFile(state);
  } else {
    state.currentWeekId = currentWeek.id;
  }

  return currentWeek;
}

// Format message for WhatsApp - Section 35 strict compliance:
// *Ave-Marias · Grupo de Intercessão*
// Semana X
//
// Nesta semana, foram rezadas *1.110* Ave-Marias. 🙏
function buildWhatsAppMessage(week: Week, records: PrayerRecord[]): string {
  const weekRecords = records.filter(r => r.weekId === week.id);
  const total = week.hasIndividualData
    ? weekRecords.reduce((acc, curr) => acc + curr.count, 0)
    : (week.fixedTotalCount || 0);

  return `*Ave-Marias · Grupo de Intercessão*\nSemana ${week.weekNumber}\n\nNesta semana, foram rezadas *${total.toLocaleString('pt-BR')}* Ave-Marias. 🙏`;
}

// WhatsApp Dispatcher (Local mode simulation or optional external webhook)
async function dispatchWhatsAppWebhook(week: Week, message: string): Promise<WebhookStatus> {
  const webhookUrl = state.settings.whatsappWebhookUrl?.trim();
  const apiKey = state.settings.whatsappApiKey?.trim();
  const evoUrl = state.settings.evolutionApiUrl?.trim();
  const evoKey = state.settings.evolutionApiKey?.trim();
  const evoInstance = state.settings.evolutionInstanceName?.trim();
  const evoTarget = state.settings.evolutionTargetJid?.trim();
  const nowIso = new Date().toISOString();

  // If running locally without external endpoints (Clean Local Environment Mode)
  if (!webhookUrl && (!evoUrl || !evoTarget)) {
    const status: WebhookStatus = {
      success: true,
      status: 200,
      message: 'Disparo registrado com sucesso no ambiente local (modo isolado sem conexões externas ativas).',
      timestamp: nowIso,
      payloadSent: { text: message, weekNumber: week.weekNumber },
    };
    week.whatsappSent = true;
    week.whatsappSentAt = nowIso;
    week.lastWebhookStatus = status;
    saveStateToFile(state);
    return status;
  }

  // If Evolution API is configured with a target group/phone
  if (evoUrl && evoTarget) {
    const cleanUrl = evoUrl.replace(/\/$/, '');
    const sendEndpoint = `${cleanUrl}/message/sendText/${evoInstance || 'intercessores'}`;
    const payload = {
      number: evoTarget,
      text: message,
    };

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12000);

      const resp = await fetch(sendEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': evoKey || '',
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const respJson = await resp.json().catch(() => ({}));
      const isSuccess = resp.status >= 200 && resp.status < 300;

      const status: WebhookStatus = {
        success: isSuccess,
        status: resp.status,
        message: isSuccess
          ? `Mensagem enviada com sucesso no WhatsApp via Evolution API! (HTTP ${resp.status})`
          : `Evolution API retornou erro HTTP ${resp.status}: ${JSON.stringify(respJson).slice(0, 150)}`,
        timestamp: nowIso,
        payloadSent: payload,
      };

      if (isSuccess) {
        week.whatsappSent = true;
        week.whatsappSentAt = nowIso;
      }
      week.lastWebhookStatus = status;
      return status;
    } catch (evoErr: any) {
      const status: WebhookStatus = {
        success: false,
        status: null,
        message: `Falha ao enviar via Evolution API: ${evoErr.message || 'Erro de conexão.'}`,
        timestamp: nowIso,
        payloadSent: payload,
      };
      week.lastWebhookStatus = status;
      return status;
    }
  }

  // Fallback to custom Webhook URL
  if (!webhookUrl) {
    const status: WebhookStatus = {
      success: true,
      status: 200,
      message: 'Disparo registrado localmente com sucesso.',
      timestamp: nowIso,
    };
    week.whatsappSent = true;
    week.whatsappSentAt = nowIso;
    week.lastWebhookStatus = status;
    return status;
  }

  const weekRecords = state.records.filter(r => r.weekId === week.id);
  const totalPrayed = week.hasIndividualData
    ? weekRecords.reduce((acc, c) => acc + c.count, 0)
    : (week.fixedTotalCount || 0);

  const payload = {
    message,
    weekNumber: week.weekNumber,
    startDate: week.startDate,
    endDate: week.endDate,
    totalPrayed,
    memberCount: week.memberCountAtWeek,
  };

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

    const resp = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(apiKey ? { 'Authorization': `Bearer ${apiKey}` } : {}),
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    const respText = await resp.text().catch(() => '');
    const isSuccess = resp.status >= 200 && resp.status < 300;

    const status: WebhookStatus = {
      success: isSuccess,
      status: resp.status,
      message: isSuccess
        ? `Mensagem enviada com sucesso via Webhook (HTTP ${resp.status}).`
        : `O Webhook retornou erro HTTP ${resp.status}: ${respText.slice(0, 120)}`,
      timestamp: nowIso,
      payloadSent: payload,
    };

    if (isSuccess) {
      week.whatsappSent = true;
      week.whatsappSentAt = nowIso;
    }
    week.lastWebhookStatus = status;
    return status;
  } catch (err: any) {
    const isAbort = err.name === 'AbortError';
    const status: WebhookStatus = {
      success: false,
      status: null,
      message: isAbort
        ? 'Tempo limite esgotado (10s) ao tentar conectar ao Webhook.'
        : `Erro de conexão ao Webhook: ${err.message || 'Falha de rede.'}`,
      timestamp: nowIso,
      payloadSent: payload,
    };
    week.lastWebhookStatus = status;
    return status;
  }
}

// API Routes
app.get('/api/state', (req, res) => {
  ensureCurrentWeek();
  res.json({
    ...state,
    serverTimeBRT: getBrasiliaNow().toISOString(),
  });
});

// Register or update count for an intercessor in a week
app.post('/api/records', async (req, res) => {
  try {
    const { weekId, intercessorId, count } = req.body;

    if (!weekId || !intercessorId || typeof count !== 'number' || !Number.isInteger(count) || count < 0) {
      return res.status(400).json({ error: 'Dados inválidos. O número de Ave-Marias deve ser um número inteiro igual ou maior que zero.' });
    }

    const intercessor = state.intercessors.find(i => i.id === intercessorId && i.active);
    if (!intercessor) {
      return res.status(404).json({ error: 'Intercessor não encontrado ou inativo.' });
    }

    let week = state.weeks.find(w => w.id === weekId);
    if (!week) {
      return res.status(404).json({ error: 'Semana não encontrada.' });
    }

    // Find or update record (REPLACES value, does not sum)
    const existingIndex = state.records.findIndex(r => r.weekId === weekId && r.intercessorId === intercessorId);
    const nowIso = new Date().toISOString();
    let updatedRecord: PrayerRecord;

    if (existingIndex >= 0) {
      state.records[existingIndex].count = count;
      state.records[existingIndex].updatedAt = nowIso;
      updatedRecord = state.records[existingIndex];
    } else {
      updatedRecord = {
        id: `rec-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        weekId,
        intercessorId,
        count,
        updatedAt: nowIso,
      };
      state.records.push(updatedRecord);
    }

    // Check if ALL active intercessors have now answered this week
    const activeMembers = state.intercessors.filter(i => i.active);
    const weekRecords = state.records.filter(r => r.weekId === weekId);
    const allAnswered = activeMembers.every(m => weekRecords.some(r => r.intercessorId === m.id));

    let justTriggeredWhatsapp = false;
    let webhookResult: WebhookStatus | null = null;
    let whatsappMessage = '';

    // If all answered and WhatsApp not yet sent for this week:
    if (allAnswered && !week.whatsappSent) {
      whatsappMessage = buildWhatsAppMessage(week, state.records);

      if (state.settings.whatsappWebhookUrl && state.settings.enableAutoWhatsapp) {
        webhookResult = await dispatchWhatsAppWebhook(week, whatsappMessage);
        if (webhookResult.success) {
          justTriggeredWhatsapp = true;
        }
      }
    }

    saveStateToFile(state);

    return res.json({
      success: true,
      record: updatedRecord,
      allAnswered,
      justTriggeredWhatsapp,
      week,
      whatsappMessage,
      webhookStatus: webhookResult || week.lastWebhookStatus,
    });
  } catch (err: any) {
    console.error('Error saving record:', err);
    return res.status(500).json({ error: 'Não foi possível salvar o registro agora. Tente novamente.' });
  }
});

// Add new intercessor
app.post('/api/intercessors', (req, res) => {
  try {
    const { name } = req.body;
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ error: 'Nome do intercessor é obrigatório.' });
    }

    const trimmedName = name.trim();
    const exists = state.intercessors.some(i => i.name.toLowerCase() === trimmedName.toLowerCase() && i.active);
    if (exists) {
      return res.status(400).json({ error: `Já existe um intercessor cadastrado com o nome "${trimmedName}".` });
    }

    const newIntercessor: Intercessor = {
      id: `int-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: trimmedName,
      joinedAt: new Date().toISOString(),
      active: true,
    };

    state.intercessors.push(newIntercessor);

    // Update CURRENT week target only (historical weeks are preserved!)
    const currentWeek = ensureCurrentWeek();
    const activeMembersCount = state.intercessors.filter(i => i.active).length;
    currentWeek.memberCountAtWeek = activeMembersCount;
    currentWeek.totalTarget = activeMembersCount * 140;

    saveStateToFile(state);

    return res.json({
      success: true,
      intercessor: newIntercessor,
      currentWeek,
    });
  } catch (err) {
    console.error('Error adding intercessor:', err);
    return res.status(500).json({ error: 'Não foi possível adicionar o intercessor agora.' });
  }
});

// Trigger or mark WhatsApp message for week via real Webhook
app.post('/api/whatsapp/send', async (req, res) => {
  try {
    const { weekId } = req.body;
    const week = state.weeks.find(w => w.id === weekId);
    if (!week) {
      return res.status(404).json({ error: 'Semana não encontrada.' });
    }

    const message = buildWhatsAppMessage(week, state.records);

    const webhookStatus = await dispatchWhatsAppWebhook(week, message);
    saveStateToFile(state);

    if (!webhookStatus.success) {
      return res.status(502).json({
        error: webhookStatus.message,
        webhookStatus,
        message,
      });
    }

    return res.json({
      success: true,
      week,
      message,
      webhookStatus,
    });
  } catch (err: any) {
    console.error('Error sending WhatsApp message:', err);
    return res.status(500).json({ error: 'Não foi possível processar o envio ao WhatsApp.' });
  }
});

// Test Webhook connectivity in real time
app.post('/api/whatsapp/test-webhook', async (req, res) => {
  try {
    const { webhookUrl, apiKey } = req.body;
    const targetUrl = webhookUrl || state.settings.whatsappWebhookUrl;

    if (!targetUrl || typeof targetUrl !== 'string' || !targetUrl.trim().startsWith('http')) {
      return res.status(400).json({ error: 'Informe uma URL de Webhook válida (iniciando com http:// ou https://).' });
    }

    const testPayload = {
      message: "*Ave-Marias · Grupo de Intercessão*\nSemana 17\n\nNesta semana, foram rezadas *1.260* Ave-Marias. 🙏",
      isTest: true,
      timestamp: new Date().toISOString(),
    };

    const startTime = Date.now();
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    const resp = await fetch(targetUrl.trim(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(apiKey ? { 'Authorization': `Bearer ${apiKey}` } : (state.settings.whatsappApiKey ? { 'Authorization': `Bearer ${state.settings.whatsappApiKey}` } : {})),
      },
      body: JSON.stringify(testPayload),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);
    const latencyMs = Date.now() - startTime;
    const respText = await resp.text().catch(() => '');

    const isSuccess = resp.status >= 200 && resp.status < 300;

    return res.json({
      success: isSuccess,
      status: resp.status,
      latencyMs,
      responseBody: respText.slice(0, 300),
      message: isSuccess
        ? `Webhook respondeu com sucesso! (HTTP ${resp.status}, ${latencyMs}ms)`
        : `Webhook retornou código de erro HTTP ${resp.status} (${latencyMs}ms)`,
    });
  } catch (err: any) {
    return res.status(502).json({
      success: false,
      status: null,
      error: `Não foi possível conectar ao Webhook: ${err.message || 'Erro de conexão ou timeout.'}`,
    });
  }
});

// Trigger notification test (12h or 18h)
app.post('/api/notifications/trigger', (req, res) => {
  try {
    const { type, weekId: requestedWeekId } = req.body;
    const weekId = requestedWeekId || state.currentWeekId;
    const week = state.weeks.find(w => w.id === weekId) || ensureCurrentWeek();
    const activeMembers = state.intercessors.filter(i => i.active);
    const weekRecords = state.records.filter(r => r.weekId === week.id);

    let recipients: Intercessor[] = [];
    let messageText = '';

    if (type === 'monday_12h') {
      recipients = [...activeMembers];
      messageText = 'Não esqueça de registrar suas Ave-Marias desta semana. Que Nossa Senhora abençoe sua oração! 🙏';
    } else if (type === 'monday_18h') {
      recipients = activeMembers.filter(m => !weekRecords.some(r => r.intercessorId === m.id));
      messageText = 'Lembrete de intercessão: ainda não recebemos seu registro de Ave-Marias desta semana. Reserve um minuto para registrar!';
    } else {
      return res.status(400).json({ error: 'Tipo de notificação inválido. Use "monday_12h" ou "monday_18h".' });
    }

    const log: NotificationLog = {
      id: `notif-${Date.now()}`,
      weekId: week.id,
      type,
      sentAt: new Date().toISOString(),
      recipientsCount: recipients.length,
      recipientNames: recipients.map(r => r.name),
      message: messageText,
    };

    state.notifications.unshift(log);
    if (state.notifications.length > 50) {
      state.notifications = state.notifications.slice(0, 50);
    }

    saveStateToFile(state);

    // Send push notification to all registered devices (reaches devices even when browser/site is closed!)
    const pushTitle = type === 'monday_12h' 
      ? 'Ave-Marias · Lembrete das 12:00' 
      : 'Ave-Marias · Lembrete das 18:00';
    sendPushToAll(pushTitle, messageText, '/');

    return res.json({
      success: true,
      log,
      recipientsCount: recipients.length,
      recipientNames: recipients.map(r => r.name),
    });
  } catch (err) {
    console.error('Error triggering notification:', err);
    return res.status(500).json({ error: 'Erro ao acionar notificações.' });
  }
});

// Web Push Registration Endpoints
app.get('/api/push/public-key', (req, res) => {
  res.json({ publicKey: VAPID_PUBLIC_KEY });
});

app.post('/api/push/subscribe', (req, res) => {
  try {
    const subscription = req.body;
    if (!subscription || !subscription.endpoint) {
      return res.status(400).json({ error: 'Inscrição de push inválida.' });
    }

    const exists = pushSubscriptions.some(s => s.endpoint === subscription.endpoint);
    if (!exists) {
      pushSubscriptions.push(subscription);
      saveSubscriptions();
    }

    res.json({ success: true, count: pushSubscriptions.length });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// Update settings
app.put('/api/settings', (req, res) => {
  try {
    const { 
      whatsappGroupLink, 
      whatsappWebhookUrl, 
      whatsappApiKey, 
      enableAutoWhatsapp,
      evolutionApiUrl,
      evolutionApiKey,
      evolutionInstanceName,
      evolutionTargetJid,
    } = req.body;

    state.settings = {
      whatsappGroupLink: whatsappGroupLink || state.settings.whatsappGroupLink,
      whatsappWebhookUrl: whatsappWebhookUrl !== undefined ? whatsappWebhookUrl : state.settings.whatsappWebhookUrl,
      whatsappApiKey: whatsappApiKey !== undefined ? whatsappApiKey : state.settings.whatsappApiKey,
      enableAutoWhatsapp: enableAutoWhatsapp !== undefined ? enableAutoWhatsapp : state.settings.enableAutoWhatsapp,
      evolutionApiUrl: evolutionApiUrl !== undefined ? evolutionApiUrl : (state.settings.evolutionApiUrl || ''),
      evolutionApiKey: evolutionApiKey !== undefined ? evolutionApiKey : (state.settings.evolutionApiKey || ''),
      evolutionInstanceName: evolutionInstanceName !== undefined ? evolutionInstanceName : (state.settings.evolutionInstanceName || ''),
      evolutionTargetJid: evolutionTargetJid !== undefined ? evolutionTargetJid : (state.settings.evolutionTargetJid || ''),
    };
    saveStateToFile(state);
    return res.json({ success: true, settings: state.settings });
  } catch (err) {
    return res.status(500).json({ error: 'Erro ao atualizar configurações.' });
  }
});

// Evolution API: Connect and Get QR Code (Clean local or external if configured)
app.post('/api/evolution/connect', async (req, res) => {
  try {
    const apiUrl = (req.body.evolutionApiUrl || state.settings.evolutionApiUrl || '').trim().replace(/\/$/, '');
    const apiKey = (req.body.evolutionApiKey || state.settings.evolutionApiKey || '').trim();
    const instanceName = (req.body.evolutionInstanceName || state.settings.evolutionInstanceName || 'intercessores').trim();

    if (!apiUrl) {
      return res.json({
        success: true,
        instanceName: 'local',
        data: {
          pairingCode: null,
          message: 'Modo local ativo: nenhuma URL externa da Evolution API configurada.',
        },
      });
    }

    // 1. Check or Create Instance
    try {
      await fetch(`${apiUrl}/instance/create`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': apiKey,
        },
        body: JSON.stringify({
          instanceName,
          token: apiKey,
          qrcode: true,
          integration: 'WHATSAPP-BAILEYS',
        }),
      });
    } catch (e) {
      // Instance might already exist, continue
    }

    // 2. Fetch Connection State / QR Code
    const connectResp = await fetch(`${apiUrl}/instance/connect/${instanceName}`, {
      method: 'GET',
      headers: {
        'apikey': apiKey,
      },
    });

    const connectData = await connectResp.json().catch(() => ({}));

    // If Evolution returns raw string code, render it as real base64 QR image
    if (connectData && connectData.code && (!connectData.base64 && !connectData.qrcode?.base64)) {
      try {
        const qrImage = await QRCode.toDataURL(connectData.code, {
          margin: 2,
          width: 300,
          color: {
            dark: '#1C2024',
            light: '#FFFFFF',
          },
        });
        connectData.base64 = qrImage;
      } catch (qrErr) {
        console.error('Failed to generate QR from code string:', qrErr);
      }
    }

    state.settings.evolutionApiUrl = apiUrl;
    state.settings.evolutionApiKey = apiKey;
    state.settings.evolutionInstanceName = instanceName;
    saveStateToFile(state);

    return res.json({
      success: true,
      instanceName,
      data: connectData,
    });
  } catch (err: any) {
    console.error('Evolution connect error:', err);
    return res.status(500).json({ error: `Erro ao conectar com a Evolution API: ${err.message}` });
  }
});

// Evolution API: Check status
app.get('/api/evolution/status', async (req, res) => {
  try {
    const apiUrl = (state.settings.evolutionApiUrl || '').trim().replace(/\/$/, '');
    const apiKey = (state.settings.evolutionApiKey || '').trim();
    const instanceName = (state.settings.evolutionInstanceName || 'intercessores').trim();

    if (!apiUrl) {
      return res.json({ success: true, state: 'local_mode', message: 'Ambiente local (sem conexão externa)' });
    }

    const resp = await fetch(`${apiUrl}/instance/connectionState/${instanceName}`, {
      headers: { 'apikey': apiKey },
    });

    const data = await resp.json().catch(() => ({}));
    return res.json({ success: true, state: data?.instance?.state || data?.state || 'disconnected', raw: data });
  } catch (err: any) {
    return res.json({ success: false, state: 'offline', error: err.message });
  }
});

// Evolution API: Fetch groups
app.get('/api/evolution/groups', async (req, res) => {
  try {
    const apiUrl = (state.settings.evolutionApiUrl || '').trim().replace(/\/$/, '');
    const apiKey = (state.settings.evolutionApiKey || '').trim();
    const instanceName = (state.settings.evolutionInstanceName || 'intercessores').trim();

    if (!apiUrl) {
      return res.json({
        success: true,
        groups: [
          { id: 'grupo-local-intercessores', subject: 'Grupo Ave-Marias Intercessores (Local)' }
        ]
      });
    }

    const resp = await fetch(`${apiUrl}/group/fetchAllGroups/${instanceName}?getParticipants=false`, {
      headers: { 'apikey': apiKey },
    });

    const groups = await resp.json().catch(() => []);
    return res.json({ success: true, groups: Array.isArray(groups) ? groups : [] });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Reset data to initial state (for testing & demo purposes)
app.post('/api/reset-data', (req, res) => {
  state = getInitialAppState();
  saveStateToFile(state);
  return res.json({ success: true, state });
});

// Scheduled check for Monday 12:00 and 18:00 (Brasília time)
let lastCheckedHour = -1;
let lastCheckedDay = -1;

setInterval(() => {
  try {
    const brt = getBrasiliaNow();
    const day = brt.getDay(); // 1 = Monday
    const hour = brt.getHours();
    const minute = brt.getMinutes();

    ensureCurrentWeek();

    if (day === 1) {
      if (hour === 12 && minute === 0 && (lastCheckedHour !== 12 || lastCheckedDay !== day)) {
        lastCheckedHour = 12;
        lastCheckedDay = day;
        console.log('[Scheduler] Triggering Monday 12h notification for all intercessors');
        const currentWeek = ensureCurrentWeek();
        const activeMembers = state.intercessors.filter(i => i.active);
        const log: NotificationLog = {
          id: `notif-${Date.now()}`,
          weekId: currentWeek.id,
          type: 'monday_12h',
          sentAt: new Date().toISOString(),
          recipientsCount: activeMembers.length,
          recipientNames: activeMembers.map(i => i.name),
          message: 'Não esqueça de registrar suas Ave-Marias desta semana. Que Nossa Senhora abençoe sua oração! 🙏'
        };
        state.notifications.unshift(log);
        saveStateToFile(state);
        sendPushToAll('Ave-Marias · Lembrete das 12:00', log.message, '/');
      } else if (hour === 18 && minute === 0 && (lastCheckedHour !== 18 || lastCheckedDay !== day)) {
        lastCheckedHour = 18;
        lastCheckedDay = day;
        console.log('[Scheduler] Triggering Monday 18h notification for pending intercessors');
        const currentWeek = ensureCurrentWeek();
        const activeMembers = state.intercessors.filter(i => i.active);
        const weekRecords = state.records.filter(r => r.weekId === currentWeek.id);
        const pending = activeMembers.filter(m => !weekRecords.some(r => r.intercessorId === m.id));

        if (pending.length > 0) {
          const log: NotificationLog = {
            id: `notif-${Date.now()}`,
            weekId: currentWeek.id,
            type: 'monday_18h',
            sentAt: new Date().toISOString(),
            recipientsCount: pending.length,
            recipientNames: pending.map(i => i.name),
            message: 'Lembrete de intercessão: ainda não recebemos seu registro de Ave-Marias desta semana.'
          };
          state.notifications.unshift(log);
          saveStateToFile(state);
          sendPushToAll('Ave-Marias · Lembrete das 18:00', log.message, '/');
        }
      }
    }
  } catch (e) {
    console.error('Scheduler error:', e);
  }
}, 30000);

// Dedicated cron endpoints (compatible with Vercel Cron, GitHub Actions, cron-job.org)
app.get('/api/cron/monday-12h', (req, res) => {
  try {
    const currentWeek = ensureCurrentWeek();
    const activeMembers = state.intercessors.filter(i => i.active);
    const log: NotificationLog = {
      id: `notif-${Date.now()}`,
      weekId: currentWeek.id,
      type: 'monday_12h',
      sentAt: new Date().toISOString(),
      recipientsCount: activeMembers.length,
      recipientNames: activeMembers.map(i => i.name),
      message: 'Não esqueça de registrar suas Ave-Marias desta semana. Que Nossa Senhora abençoe sua oração! 🙏'
    };
    state.notifications.unshift(log);
    saveStateToFile(state);
    return res.json({ success: true, cron: 'monday_12h', recipients: activeMembers.length });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.get('/api/cron/monday-18h', (req, res) => {
  try {
    const currentWeek = ensureCurrentWeek();
    const activeMembers = state.intercessors.filter(i => i.active);
    const weekRecords = state.records.filter(r => r.weekId === currentWeek.id);
    const pending = activeMembers.filter(m => !weekRecords.some(r => r.intercessorId === m.id));

    if (pending.length > 0) {
      const log: NotificationLog = {
        id: `notif-${Date.now()}`,
        weekId: currentWeek.id,
        type: 'monday_18h',
        sentAt: new Date().toISOString(),
        recipientsCount: pending.length,
        recipientNames: pending.map(i => i.name),
        message: 'Lembrete de intercessão: ainda não recebemos seu registro de Ave-Marias desta semana.'
      };
      state.notifications.unshift(log);
      saveStateToFile(state);
    }
    return res.json({ success: true, cron: 'monday_18h', pendingCount: pending.length, pendingNames: pending.map(p => p.name) });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
