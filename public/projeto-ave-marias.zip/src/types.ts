export interface Intercessor {
  id: string;
  name: string;
  joinedAt: string;
  active: boolean; // true for current 9 active members; false for historical-only members
  isHistoricalOnly?: boolean;
}

export interface WebhookStatus {
  success: boolean;
  status: number | null;
  message: string;
  timestamp: string;
  payloadSent?: any;
}

export interface Week {
  id: string; // "2026-09-28" (Monday's date)
  weekNumber: number; // 1 to 17+
  startDate: string; // "2026-09-28"
  endDate: string; // "2026-10-04"
  targetPerMember: number; // 140
  memberCountAtWeek: number; // e.g. 9 or 11
  totalTarget: number; // memberCountAtWeek * 140
  hasIndividualData: boolean; // false for weeks 4, 6-15
  fixedTotalCount?: number; // for weeks where only the total is known
  whatsappSent: boolean;
  whatsappSentAt: string | null;
  lastWebhookStatus?: WebhookStatus | null;
}

export interface PrayerRecord {
  id: string;
  weekId: string;
  intercessorId: string;
  count: number; // >= 0. Note: 0 means responded! Absence of record means pending.
  updatedAt: string;
}

export interface NotificationLog {
  id: string;
  weekId: string;
  type: 'monday_12h' | 'monday_18h' | 'manual_test';
  sentAt: string;
  recipientsCount: number;
  recipientNames: string[];
  message: string;
}

export interface AppSettings {
  whatsappGroupLink: string;
  whatsappWebhookUrl: string;
  whatsappApiKey: string;
  enableAutoWhatsapp: boolean;
  evolutionApiUrl?: string;
  evolutionApiKey?: string;
  evolutionInstanceName?: string;
  evolutionTargetJid?: string; // Group JID or Phone number
}

export interface AppState {
  intercessors: Intercessor[];
  weeks: Week[];
  records: PrayerRecord[];
  notifications: NotificationLog[];
  settings: AppSettings;
  currentWeekId: string;
}

