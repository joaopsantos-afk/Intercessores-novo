import { AppState, PrayerRecord, Intercessor, Week, AppSettings } from '../types';
import { getInitialAppState } from '../initialData';

const LOCAL_STORAGE_KEY = 'ave_marias_backup_state_v1';

function getLocalBackup(): AppState {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to read from localStorage:', e);
  }
  return getInitialAppState();
}

function saveLocalBackup(state: AppState) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save to localStorage:', e);
  }
}

export async function fetchAppState(): Promise<AppState & { serverTimeBRT?: string; source?: string }> {
  // 1. Fetch from local backend API
  try {
    const res = await fetch('/api/state');
    if (res.ok) {
      const data = await res.json();
      saveLocalBackup(data);
      return { ...data, source: 'backend' };
    }
  } catch (err) {
    console.warn('Backend fetch failed, using local storage cache:', err);
  }

  // 2. Fallback to localStorage / initial data
  return { ...getLocalBackup(), source: 'local' };
}

export async function saveRecord(
  weekId: string,
  intercessorId: string,
  count: number
): Promise<{
  success: boolean;
  record: PrayerRecord;
  allAnswered: boolean;
  justTriggeredWhatsapp: boolean;
  week: Week;
  whatsappMessage?: string;
}> {
  // 1. Send to local backend
  try {
    const res = await fetch('/api/records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ weekId, intercessorId, count }),
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('Backend /api/records unreachable, saving to local cache:', err);
  }

  // 2. Local fallback
  const fallbackRec: PrayerRecord = {
    id: `rec-${weekId}-${intercessorId}`,
    weekId,
    intercessorId,
    count,
    updatedAt: new Date().toISOString(),
  };

  const localState = getLocalBackup();
  const existingIdx = localState.records.findIndex(
    r => r.weekId === weekId && r.intercessorId === intercessorId
  );
  if (existingIdx >= 0) {
    localState.records[existingIdx] = fallbackRec;
  } else {
    localState.records.push(fallbackRec);
  }
  saveLocalBackup(localState);

  const week = localState.weeks.find(w => w.id === weekId) || {
    id: weekId,
    weekNumber: 17,
    startDate: '2026-09-28',
    endDate: '2026-10-04',
    targetPerMember: 140,
    memberCountAtWeek: 9,
    totalTarget: 1260,
    hasIndividualData: true,
    whatsappSent: false,
    whatsappSentAt: null,
  };

  return {
    success: true,
    record: fallbackRec,
    allAnswered: false,
    justTriggeredWhatsapp: false,
    week,
  };
}

export async function addIntercessor(name: string): Promise<{
  success: boolean;
  intercessor: Intercessor;
  currentWeek: Week;
}> {
  try {
    const res = await fetch('/api/intercessors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });

    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('Backend unavailable, saving intercessor to local cache:', err);
  }

  const newInt: Intercessor = {
    id: `int-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    name: name.trim(),
    joinedAt: new Date().toISOString(),
    active: true,
  };

  const localState = getLocalBackup();
  localState.intercessors.push(newInt);
  saveLocalBackup(localState);

  const currentWeek = localState.weeks[localState.weeks.length - 1] || {
    id: '2026-09-28',
    weekNumber: 17,
    startDate: '2026-09-28',
    endDate: '2026-10-04',
    targetPerMember: 140,
    memberCountAtWeek: localState.intercessors.filter(i => i.active).length,
    totalTarget: localState.intercessors.filter(i => i.active).length * 140,
    hasIndividualData: true,
    whatsappSent: false,
    whatsappSentAt: null,
  };

  return {
    success: true,
    intercessor: newInt,
    currentWeek,
  };
}

export async function triggerWhatsAppSend(weekId: string): Promise<{
  success: boolean;
  week: Week;
  message: string;
  webhookStatus: any;
}> {
  const res = await fetch('/api/whatsapp/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ weekId }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || 'Não foi possível registrar o envio do WhatsApp.');
  }

  return res.json();
}

export async function testWebhookConnectivity(webhookUrl?: string, apiKey?: string): Promise<{
  success: boolean;
  status: number | null;
  latencyMs: number;
  message: string;
  responseBody?: string;
  error?: string;
}> {
  const res = await fetch('/api/whatsapp/test-webhook', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ webhookUrl, apiKey }),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Falha ao testar Webhook.');
  }

  return data;
}

export async function triggerNotification(
  type: 'monday_12h' | 'monday_18h',
  weekId?: string
): Promise<{
  success: boolean;
  recipientsCount: number;
  recipientNames: string[];
}> {
  const res = await fetch('/api/notifications/trigger', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type, weekId }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || 'Erro ao disparar notificações.');
  }

  return res.json();
}

export async function updateSettings(settings: Partial<AppSettings>): Promise<{
  success: boolean;
  settings: AppSettings;
}> {
  const res = await fetch('/api/settings', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(settings),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || 'Erro ao atualizar configurações.');
  }

  return res.json();
}

export async function connectEvolutionApi(params: {
  evolutionApiUrl?: string;
  evolutionApiKey?: string;
  evolutionInstanceName?: string;
}): Promise<{
  success: boolean;
  instanceName: string;
  data: any;
}> {
  const res = await fetch('/api/evolution/connect', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  return res.json();
}

export async function getEvolutionStatus(): Promise<{
  success: boolean;
  state: string;
  raw?: any;
}> {
  const res = await fetch('/api/evolution/status');
  return res.json();
}

export async function getEvolutionGroups(): Promise<{
  success: boolean;
  groups: Array<{ id: string; subject: string; size?: number }>;
}> {
  const res = await fetch('/api/evolution/groups');
  return res.json();
}

export async function resetDatabase(): Promise<{ success: boolean; state: AppState }> {
  try {
    const res = await fetch('/api/reset-data', { method: 'POST' });
    if (res.ok) {
      return res.json();
    }
  } catch (e) {
    console.warn('Backend reset failed, resetting local cache:', e);
  }

  const initial = getInitialAppState();
  saveLocalBackup(initial);
  return { success: true, state: initial };
}
