import React from 'react';
import { Week, Intercessor, PrayerRecord } from '../types';
import { formatWeekPeriod, formatDateTimeBRT } from '../utils/date';
import { CheckCircle2, Clock, MessageCircle, UserPlus, Check } from 'lucide-react';

interface WeekDashboardProps {
  currentWeek: Week;
  intercessors: Intercessor[];
  records: PrayerRecord[];
  onOpenRegisterFor: (intercessorId?: string) => void;
  onOpenAddMember: () => void;
}

export const WeekDashboard: React.FC<WeekDashboardProps> = ({
  currentWeek,
  intercessors,
  records,
  onOpenRegisterFor,
  onOpenAddMember,
}) => {
  const activeIntercessors = intercessors.filter(i => i.active);
  const weekRecords = records.filter(r => r.weekId === currentWeek.id);
  
  const totalPrayed = weekRecords.reduce((acc, r) => acc + r.count, 0);
  const totalTarget = activeIntercessors.length * 140;
  const progressPercent = totalTarget > 0 ? Math.round((totalPrayed / totalTarget) * 100) : 0;

  const respondedMembers = activeIntercessors.filter(i => weekRecords.some(r => r.intercessorId === i.id));
  const pendingMembers = activeIntercessors.filter(i => !weekRecords.some(r => r.intercessorId === i.id));
  const allAnswered = activeIntercessors.length > 0 && pendingMembers.length === 0;

  const periodFormatted = formatWeekPeriod(currentWeek.startDate, currentWeek.endDate);

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Top Banner: All Answered Milestone Celebration */}
      {allAnswered && (
        <div className="p-4 sm:p-5 liquid-glass rounded-2xl flex items-center justify-between gap-4 transition-all">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-xs">
              <CheckCircle2 className="w-5 h-5 text-emerald-100" />
            </div>
            <div>
              <h3 className="font-editorial text-base sm:text-lg font-semibold text-[#1C2024]">
                Todos os {activeIntercessors.length} intercessores responderam!
              </h3>
              <p className="text-xs text-[#526354]">
                Total de {totalPrayed.toLocaleString('pt-BR')} Ave-Marias nesta semana. 🙏
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-xs font-semibold text-emerald-800 bg-emerald-100/70 border border-emerald-300 px-3.5 py-1.5 rounded-xl">
            <Check className="w-3.5 h-3.5 text-emerald-600" />
            <span>Semana concluída</span>
          </div>
        </div>
      )}

      {/* Central Metric Card: Pure Information with Liquid Glass Effect (No Register Button) */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 relative overflow-hidden transition-all">
        {/* Context metadata */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#706B62] mb-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#58111A] tracking-wider uppercase text-[11px] bg-[#58111A]/8 px-2.5 py-1 rounded-lg">
              Semana {currentWeek.weekNumber}
            </span>
            <span className="font-medium text-[#1C2024] text-xs sm:text-sm">
              {periodFormatted}
            </span>
          </div>
          <span className="text-[11px] text-[#8E877C]">Brasília (UTC-3)</span>
        </div>

        {/* Big numbers (Clean & Informative Only) */}
        <div className="mt-2">
          <div className="flex items-baseline gap-1.5 sm:gap-2">
            <span className="text-4xl sm:text-5xl md:text-6xl font-editorial font-medium text-[#1C2024] tracking-tight tabular-nums">
              {totalPrayed.toLocaleString('pt-BR')}
            </span>
            <span className="text-xl sm:text-2xl text-[#8E877C] font-editorial tabular-nums">
              / {totalTarget.toLocaleString('pt-BR')}
            </span>
            <span className="text-xs sm:text-sm font-medium text-[#706B62] ml-1">
              Ave-Marias
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#706B62] mt-1.5 font-medium">
            {progressPercent}% da meta do grupo {progressPercent > 100 && '— superada com louvor! 🎉'}
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mt-6">
          <div className="w-full h-3 bg-[#F2EDE4]/80 rounded-full overflow-hidden p-0.5 border border-[#EAE4D7]/80">
            <div
              className="h-full bg-gradient-to-r from-[#58111A] via-[#731320] to-[#801B28] rounded-full transition-all duration-700 ease-out shadow-xs"
              style={{ width: `${Math.min(progressPercent, 100)}%` }}
            />
          </div>
        </div>

        {/* Unboxed Metadata Stats */}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-5 pt-4 border-t border-[#F2EDE4]/80 text-xs text-[#706B62]">
          <div className="flex items-center gap-1.5 font-medium text-[#1C2024]">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{respondedMembers.length} de {activeIntercessors.length} responderam</span>
          </div>
          <span aria-hidden="true" className="text-[#D9D1C3]">·</span>
          <div className="flex items-center gap-1.5 font-medium">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>
              {pendingMembers.length === 0
                ? 'Todos responderam'
                : `${pendingMembers.length} ${pendingMembers.length === 1 ? 'pendente' : 'pendentes'}`}
            </span>
          </div>
          <span aria-hidden="true" className="text-[#D9D1C3]">·</span>
          <span>Meta: 140 / intercessor</span>
        </div>
      </div>

      {/* Bottom Section: Intercessors List & The Exclusive Action Buttons */}
      <div className="liquid-glass rounded-3xl overflow-hidden transition-all">
        <div className="px-5 py-4 border-b border-[#EFEAE1]/80 bg-[#FBF9F5]/40 flex items-center justify-between">
          <div>
            <h2 className="font-editorial text-base sm:text-lg font-semibold text-[#1C2024]">
              Intercessores do Grupo
            </h2>
            <p className="text-xs text-[#706B62]">
              Registro individual na semana atual
            </p>
          </div>
          
          {/* Exclusive 'Adicionar membro' Action */}
          <button
            onClick={onOpenAddMember}
            className="text-xs font-semibold text-[#58111A] hover:text-[#430C13] active:scale-[0.97] bg-[#58111A]/6 hover:bg-[#58111A]/10 border border-[#58111A]/15 px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer touch-manipulation"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Adicionar membro</span>
          </button>
        </div>

        {/* List items - Pure Names without letter circles */}
        <div className="divide-y divide-[#F2EDE4]/70">
          {activeIntercessors.map((person) => {
            const record = weekRecords.find(r => r.intercessorId === person.id);
            const hasAnswered = record !== undefined;
            const count = hasAnswered ? record.count : null;
            const personTarget = 140;
            const personPercent = count !== null ? Math.round((count / personTarget) * 100) : 0;

            return (
              <div
                key={person.id}
                onClick={() => onOpenRegisterFor(person.id)}
                className="px-5 py-3.5 flex items-center justify-between gap-3 hover:bg-white/50 active:bg-white/80 transition-colors cursor-pointer group"
              >
                {/* Person details - Pure Name without initial circle */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-[#1C2024] text-sm group-hover:text-[#58111A] transition-colors truncate">
                      {person.name}
                    </span>
                    {hasAnswered ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 shrink-0">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="hidden sm:inline">Atualizado</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-700 shrink-0">
                        <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                        <span>Aguardando</span>
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-[#706B62] mt-0.5 truncate">
                    {hasAnswered && record.updatedAt ? (
                      <span>Atualizado em {formatDateTimeBRT(record.updatedAt)}</span>
                    ) : (
                      <span>Ainda não registrou nesta semana</span>
                    )}
                  </div>
                </div>

                {/* Person metrics & action */}
                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right">
                    {hasAnswered ? (
                      <div className="tabular-nums">
                        <span className="text-sm sm:text-base font-bold text-[#1C2024]">
                          {count}
                        </span>
                        <span className="text-[11px] text-[#706B62]"> / 140</span>
                        <div className="w-16 sm:w-24 h-1.5 bg-[#F2EDE4] rounded-full overflow-hidden mt-1 ml-auto">
                          <div
                            className={`h-full rounded-full transition-all duration-300 ${
                              (count ?? 0) >= 140 ? 'bg-emerald-600' : 'bg-[#58111A]'
                            }`}
                            style={{ width: `${Math.min(personPercent, 100)}%` }}
                          />
                        </div>
                      </div>
                    ) : (
                      <span className="text-xs text-[#8E877C] italic">
                        Pendente
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenRegisterFor(person.id);
                    }}
                    className="h-8.5 px-3.5 text-xs font-semibold rounded-xl text-white bg-[#58111A] hover:bg-[#430C13] active:bg-[#32080D] active:scale-[0.96] shadow-xs hover:shadow-sm transition-all flex items-center justify-center shrink-0 cursor-pointer touch-manipulation"
                  >
                    Registrar
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
