import React, { useState, useEffect, useCallback } from 'react';
import { AppState, Week, Intercessor, PrayerRecord } from './types';
import { 
  fetchAppState, 
  saveRecord, 
  addIntercessor, 
  resetDatabase 
} from './services/api';
import { Header } from './components/Header';
import { WeekDashboard } from './components/WeekDashboard';
import { HistoryView } from './components/HistoryView';
import { RegisterModal } from './components/RegisterModal';
import { AddMemberModal } from './components/AddMemberModal';
import { Toast, ToastMessage } from './components/Toast';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [appState, setAppState] = useState<AppState | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'current' | 'history'>('current');
  
  // Modals
  const [isRegisterOpen, setIsRegisterOpen] = useState<boolean>(false);
  const [registerIntercessorId, setRegisterIntercessorId] = useState<string | undefined>(undefined);
  const [isAddMemberOpen, setIsAddMemberOpen] = useState<boolean>(false);

  // Toast feedback
  const [toast, setToast] = useState<ToastMessage | null>(null);

  // Load state from server
  const loadState = useCallback(async () => {
    try {
      const data = await fetchAppState();
      setAppState(data);
    } catch (err) {
      console.error('Failed to load application state:', err);
      setToast({
        id: String(Date.now()),
        type: 'error',
        title: 'Falha na conexão',
        description: 'Não foi possível carregar os dados atualizados do servidor.',
      });
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadState();

    // Auto-refresh state every 20 seconds to stay in sync
    const interval = setInterval(() => {
      loadState();
    }, 20000);

    return () => clearInterval(interval);
  }, [loadState]);

  // Open register modal pre-selecting an intercessor
  const handleOpenRegisterFor = (intercessorId?: string) => {
    setRegisterIntercessorId(intercessorId);
    setIsRegisterOpen(true);
  };

  // Save prayer record
  const handleSaveRecord = async (intercessorId: string, count: number) => {
    if (!appState) return;
    const currentWeekId = appState.currentWeekId;
    const person = appState.intercessors.find(i => i.id === intercessorId);
    const personName = person ? person.name : 'Intercessor';

    try {
      const res = await saveRecord(currentWeekId, intercessorId, count);

      // Update state locally
      setAppState(prev => {
        if (!prev) return prev;
        const newRecords = [...prev.records];
        const existingIdx = newRecords.findIndex(r => r.weekId === currentWeekId && r.intercessorId === intercessorId);
        if (existingIdx >= 0) {
          newRecords[existingIdx] = res.record;
        } else {
          newRecords.push(res.record);
        }

        const newWeeks = prev.weeks.map(w => w.id === res.week.id ? res.week : w);
        return {
          ...prev,
          records: newRecords,
          weeks: newWeeks,
        };
      });

      // Feedback toast
      if (res.justTriggeredWhatsapp) {
        setToast({
          id: String(Date.now()),
          type: 'success',
          title: 'Todos responderam!',
          description: `Com o registro de ${personName}, todos os intercessores responderam esta semana. O resultado de ${res.week.memberCountAtWeek * 140} Ave-Marias está pronto.`,
        });
      } else {
        setToast({
          id: String(Date.now()),
          type: 'success',
          title: 'Registro salvo',
          description: `${personName}: ${count} Ave-Marias registradas com sucesso para esta semana.`,
        });
      }
    } catch (err: any) {
      throw new Error(err.message || 'Erro ao salvar. Verifique sua conexão e tente novamente.');
    }
  };

  // Add new intercessor
  const handleAddMember = async (name: string) => {
    try {
      const res = await addIntercessor(name);
      await loadState();

      setToast({
        id: String(Date.now()),
        type: 'success',
        title: 'Membro adicionado',
        description: `${res.intercessor.name} agora faz parte do grupo de intercessão. Nova meta semanal: ${res.currentWeek.totalTarget} Ave-Marias.`,
      });
    } catch (err: any) {
      throw new Error(err.message || 'Erro ao adicionar novo membro.');
    }
  };

  // Reset to initial data
  const handleResetData = async () => {
    if (!confirm('Deseja realmente restaurar os dados iniciais de demonstração?')) {
      return;
    }
    await resetDatabase();
    await loadState();
    setToast({
      id: String(Date.now()),
      type: 'info',
      title: 'Dados restaurados',
      description: 'O grupo foi resetado com os 9 intercessores e dados oficiais.',
    });
  };

  if (isLoading || !appState) {
    return (
      <div className="min-h-screen bg-[#FBF9F5] flex flex-col items-center justify-center p-6 text-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#233529] mb-4" />
        <h2 className="font-editorial text-xl font-medium text-[#1C2024]">
          Carregando Ave-Marias...
        </h2>
        <p className="text-xs text-[#706B62] mt-1">
          Sincronizando com o grupo de intercessão
        </p>
      </div>
    );
  }

  const currentWeek = appState.weeks.find(w => w.id === appState.currentWeekId) || appState.weeks[appState.weeks.length - 1];

  return (
    <div className="min-h-screen bg-[#F7F3EB] flex flex-col relative overflow-x-hidden selection:bg-[#58111A]/15 selection:text-[#58111A]">
      {/* Dynamic Animated Fluid Mesh Gradient Background */}
      <div 
        aria-hidden="true" 
        className="fixed inset-0 pointer-events-none overflow-hidden z-0"
      >
        {/* Warm Wine / Rose Glow */}
        <div 
          className="absolute -top-[15%] -left-[10%] w-[85vw] max-w-[650px] h-[85vw] max-h-[650px] rounded-full blur-[80px] opacity-80 animate-fluid-1"
          style={{
            background: 'radial-gradient(circle, rgba(165, 38, 58, 0.32) 0%, rgba(215, 110, 135, 0.20) 45%, transparent 70%)',
          }}
        />
        {/* Warm Champagne Gold Glow */}
        <div 
          className="absolute top-[20%] -right-[15%] w-[80vw] max-w-[600px] h-[80vw] max-h-[600px] rounded-full blur-[90px] opacity-75 animate-fluid-2"
          style={{
            background: 'radial-gradient(circle, rgba(235, 180, 115, 0.35) 0%, rgba(245, 210, 155, 0.20) 50%, transparent 75%)',
          }}
        />
        {/* Deep Marian Dawn Glow */}
        <div 
          className="absolute -bottom-[15%] left-[10%] w-[90vw] max-w-[700px] h-[90vw] max-h-[700px] rounded-full blur-[90px] opacity-70 animate-fluid-3"
          style={{
            background: 'radial-gradient(circle, rgba(138, 30, 48, 0.26) 0%, rgba(210, 140, 150, 0.18) 45%, transparent 70%)',
          }}
        />
        {/* Soft Pearlescent Core */}
        <div 
          className="absolute top-[40%] left-[20%] w-[55vw] max-w-[450px] h-[55vw] max-h-[450px] rounded-full blur-[70px] opacity-50 animate-fluid-1"
          style={{
            animationDuration: '24s',
            background: 'radial-gradient(circle, rgba(255, 255, 255, 0.9) 0%, rgba(250, 235, 220, 0.4) 50%, transparent 70%)',
          }}
        />
      </div>

      {/* Top Header with 2 clean tabs: Esta semana e Histórico */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        intercessorsCount={appState.intercessors.filter(i => i.active).length}
      />

      {/* Main Content Container - Mobile First Optimized */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3.5 sm:px-6 py-4 sm:py-7 relative z-10">
        <div className="animate-in fade-in duration-150">
          {activeTab === 'current' && (
            <WeekDashboard
              currentWeek={currentWeek}
              intercessors={appState.intercessors}
              records={appState.records}
              onOpenRegisterFor={handleOpenRegisterFor}
              onOpenAddMember={() => setIsAddMemberOpen(true)}
            />
          )}

          {activeTab === 'history' && (
            <HistoryView
              weeks={appState.weeks}
              intercessors={appState.intercessors}
              records={appState.records}
              currentWeekId={appState.currentWeekId}
              onResetData={handleResetData}
            />
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#EAE4D7] py-6 bg-[#FBF9F5] text-center text-xs text-[#8E877C]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Grupo de Intercessão · Ave-Marias Semanais</span>
          <span className="text-[11px]">
            Horário de Brasília (UTC-3) · Meta individual: 140 / semana
          </span>
        </div>
      </footer>

      {/* Register Modal */}
      <RegisterModal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        intercessors={appState.intercessors}
        currentWeek={currentWeek}
        records={appState.records}
        initialIntercessorId={registerIntercessorId}
        onSave={handleSaveRecord}
      />

      {/* Add Member Modal */}
      <AddMemberModal
        isOpen={isAddMemberOpen}
        onClose={() => setIsAddMemberOpen(false)}
        onAddMember={handleAddMember}
        existingNames={appState.intercessors.map(i => i.name)}
      />

      {/* Toast Feedback */}
      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </div>
  );
}
